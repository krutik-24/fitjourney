import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { isUnauthorizedError } from '@/lib/authUtils';
import { WorkoutGenerator } from '@/components/WorkoutGenerator';
import { Workout } from '@shared/schema';
import { 
  Dumbbell, 
  Clock, 
  Target,
  Trash2,
  Play,
  Calendar,
  Plus
} from 'lucide-react';

export default function Workouts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: workouts = [], isLoading } = useQuery<Workout[]>({
    queryKey: ['/api/workouts'],
    queryFn: async () => {
      const response = await fetch('/api/workouts');
      if (!response.ok) throw new Error('Failed to fetch workouts');
      return response.json();
    },
  });

  const deleteWorkoutMutation = useMutation({
    mutationFn: async (workoutId: number) => {
      const response = await apiRequest('DELETE', `/api/workouts/${workoutId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workouts'] });
      toast({
        title: "Workout Deleted",
        description: "The workout has been removed from your routine.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete workout. Please try again.",
        variant: "destructive",
      });
    },
  });

  const formatExercises = (exercises: any) => {
    if (!exercises || !Array.isArray(exercises)) return [];
    return exercises;
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-16 md:mb-0">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-6">
            <div className="h-96 bg-gray-200 rounded-lg animate-pulse"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-16 md:mb-0">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Header */}
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              My Workouts
            </h1>
            <Badge variant="outline" className="text-sm">
              {workouts.length} workout{workouts.length !== 1 ? 's' : ''}
            </Badge>
          </div>

          {/* Workouts List */}
          <div className="space-y-6">
            {workouts.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Dumbbell className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    No workouts yet
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    Generate your first AI-powered workout to get started!
                  </p>
                  <Button onClick={() => document.getElementById('workout-generator')?.scrollIntoView()}>
                    <Plus className="h-4 w-4 mr-2" />
                    Generate Workout
                  </Button>
                </CardContent>
              </Card>
            ) : (
              workouts.map((workout) => (
                <Card key={workout.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center">
                        <Dumbbell className="h-5 w-5 text-primary mr-2" />
                        {workout.title}
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge variant={workout.completed ? "default" : "secondary"}>
                          {workout.completed ? "Completed" : "Pending"}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteWorkoutMutation.mutate(workout.id)}
                          disabled={deleteWorkoutMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      {workout.description}
                    </p>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(workout.createdAt!)}
                      </div>
                      {workout.duration && (
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {workout.duration} min
                        </div>
                      )}
                      {workout.caloriesBurned && (
                        <div className="flex items-center">
                          <Target className="h-4 w-4 mr-1" />
                          {workout.caloriesBurned} cal
                        </div>
                      )}
                    </div>
                    
                    {workout.exercises && (
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Exercises:</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {formatExercises(workout.exercises).map((exercise: any, index: number) => (
                            <div key={index} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-800 rounded">
                              <span className="text-sm font-medium">{exercise.name}</span>
                              <div className="flex items-center space-x-2">
                                <Badge variant="outline" className="text-xs">
                                  {exercise.sets} × {exercise.reps}
                                </Badge>
                                {exercise.rest && (
                                  <Badge variant="outline" className="text-xs">
                                    {exercise.rest}s
                                  </Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-4 flex space-x-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        disabled={workout.completed}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        {workout.completed ? 'Completed' : 'Start Workout'}
                      </Button>
                      {workout.shared && (
                        <Badge variant="outline" className="flex items-center">
                          Shared
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          
          {/* AI Workout Generator */}
          <div id="workout-generator">
            <WorkoutGenerator />
          </div>

          {/* Workout Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-5 w-5 text-primary mr-2" />
                Workout Stats
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Total Workouts</span>
                  <span className="text-lg font-bold text-primary">{workouts.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Completed</span>
                  <span className="text-lg font-bold text-green-600">
                    {workouts.filter(w => w.completed).length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Pending</span>
                  <span className="text-lg font-bold text-yellow-600">
                    {workouts.filter(w => !w.completed).length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Shared</span>
                  <span className="text-lg font-bold text-blue-600">
                    {workouts.filter(w => w.shared).length}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
