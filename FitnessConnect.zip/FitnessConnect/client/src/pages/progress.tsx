import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress as ProgressBar } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BMICalculator } from '@/components/BMICalculator';
import { ProgressChart } from '@/components/ProgressChart';
import { 
  TrendingUp, 
  Target, 
  Calendar, 
  Weight, 
  Activity, 
  Clock,
  Flame,
  Trophy,
  BarChart3,
  LineChart,
  PieChart
} from 'lucide-react';

interface UserStats {
  currentStreak: number;
  totalWorkouts: number;
  weightProgress: number;
  bmiStatus: string;
}

interface WorkoutCompletion {
  id: number;
  completedDate: string;
  workoutId?: number;
}

export default function Progress() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ['/api/user/stats'],
    queryFn: async () => {
      const response = await fetch('/api/user/stats');
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    },
  });

  const { data: completions = [] } = useQuery<WorkoutCompletion[]>({
    queryKey: ['/api/workout-completions', selectedMonth, selectedYear],
    queryFn: async () => {
      const response = await fetch(`/api/workout-completions?month=${selectedMonth}&year=${selectedYear}`);
      if (!response.ok) throw new Error('Failed to fetch completions');
      return response.json();
    },
  });

  const { data: leaderboard = [] } = useQuery({
    queryKey: ['/api/leaderboard'],
    queryFn: async () => {
      const response = await fetch('/api/leaderboard?limit=10');
      if (!response.ok) throw new Error('Failed to fetch leaderboard');
      return response.json();
    },
  });

  const getCompletionRate = () => {
    const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
    const completionRate = (completions.length / daysInMonth) * 100;
    return Math.round(completionRate);
  };

  const getStreakProgress = () => {
    if (!stats) return 0;
    return Math.min((stats.currentStreak / 30) * 100, 100);
  };

  const getWorkoutProgress = () => {
    if (!stats) return 0;
    return Math.min((stats.totalWorkouts / 100) * 100, 100);
  };

  const getBMIColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'normal':
        return 'text-green-600 dark:text-green-400';
      case 'underweight':
        return 'text-blue-600 dark:text-blue-400';
      case 'overweight':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'obese':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getMonthlyStats = () => {
    const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
    const completionDays = completions.length;
    const restDays = daysInMonth - completionDays;
    
    return {
      totalDays: daysInMonth,
      workoutDays: completionDays,
      restDays,
      completionRate: getCompletionRate(),
    };
  };

  const monthlyStats = getMonthlyStats();

  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' },
  ];

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 3 }, (_, i) => currentYear - i);

  if (statsLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-16 md:mb-0">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="h-96 bg-gray-200 rounded-lg"></div>
            <div className="h-96 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-16 md:mb-0">
      <div className="space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Progress Tracking
          </h1>
          <div className="flex items-center space-x-4">
            <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((month) => (
                  <SelectItem key={month.value} value={month.value.toString()}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Current Streak</p>
                  <p className="text-3xl font-bold text-green-600">
                    {stats?.currentStreak || 0}
                  </p>
                  <p className="text-sm text-gray-500">days</p>
                </div>
                <div className="p-3 bg-green-100 dark:bg-green-900 rounded-full">
                  <Flame className="h-6 w-6 text-green-600 streak-fire" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Workouts</p>
                  <p className="text-3xl font-bold text-blue-600">
                    {stats?.totalWorkouts || 0}
                  </p>
                  <p className="text-sm text-gray-500">completed</p>
                </div>
                <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full">
                  <Activity className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Weight Progress</p>
                  <p className="text-3xl font-bold text-purple-600">
                    {stats?.weightProgress ? 
                      `${stats.weightProgress > 0 ? '+' : ''}${stats.weightProgress.toFixed(1)}` : 
                      '0.0'
                    }
                  </p>
                  <p className="text-sm text-gray-500">kg</p>
                </div>
                <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-full">
                  <Weight className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">BMI Status</p>
                  <p className={`text-3xl font-bold ${getBMIColor(stats?.bmiStatus || 'Unknown')}`}>
                    {stats?.bmiStatus || 'Unknown'}
                  </p>
                  <p className="text-sm text-gray-500">category</p>
                </div>
                <div className="p-3 bg-red-100 dark:bg-red-900 rounded-full">
                  <Target className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Progress Charts */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Monthly Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 text-primary mr-2" />
                  Monthly Overview - {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-2">
                      {monthlyStats.workoutDays}
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Workout Days</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      {monthlyStats.restDays}
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Rest Days</p>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-2">
                      {monthlyStats.completionRate}%
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Completion Rate</p>
                  </div>
                </div>
                
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Monthly Progress</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {monthlyStats.workoutDays}/{monthlyStats.totalDays} days
                    </span>
                  </div>
                  <ProgressBar value={monthlyStats.completionRate} className="h-2 progress-bar" />
                </div>
              </CardContent>
            </Card>

            {/* Goal Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 text-primary mr-2" />
                  Goal Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Workout Streak</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {stats?.currentStreak || 0}/30 days
                    </span>
                  </div>
                  <ProgressBar value={getStreakProgress()} className="h-2" />
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    Target: 30 day streak
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total Workouts</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {stats?.totalWorkouts || 0}/100 workouts
                    </span>
                  </div>
                  <ProgressBar value={getWorkoutProgress()} className="h-2" />
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    Target: 100 workouts
                  </p>
                </div>

                {stats?.weightProgress !== 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Weight Goal</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {Math.abs(stats?.weightProgress || 0).toFixed(1)}kg {stats?.weightProgress > 0 ? 'gained' : 'lost'}
                      </span>
                    </div>
                    <ProgressBar value={Math.min((Math.abs(stats?.weightProgress || 0) / 10) * 100, 100)} className="h-2" />
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                      Target: 10kg change
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Workout Calendar Visual */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 text-primary mr-2" />
                  Workout Calendar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                    <div key={day} className="text-center text-sm font-medium text-gray-600 dark:text-gray-400 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 35 }, (_, i) => {
                    const day = i + 1;
                    const isCompleted = completions.some(c => 
                      new Date(c.completedDate).getDate() === day
                    );
                    
                    return (
                      <div
                        key={i}
                        className={`aspect-square flex items-center justify-center text-sm rounded ${
                          day <= new Date(selectedYear, selectedMonth, 0).getDate()
                            ? isCompleted
                              ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 font-bold'
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                            : 'text-gray-300 dark:text-gray-600'
                        }`}
                      >
                        {day <= new Date(selectedYear, selectedMonth, 0).getDate() ? day : ''}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* BMI Calculator */}
            <BMICalculator />

            {/* Progress Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 text-primary mr-2" />
                  Progress Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="weekly" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="weekly">Weekly</TabsTrigger>
                    <TabsTrigger value="monthly">Monthly</TabsTrigger>
                  </TabsList>
                  <TabsContent value="weekly" className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Workouts</span>
                        <Badge variant="outline">5/7</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Rest Days</span>
                        <Badge variant="outline">2/7</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Streak</span>
                        <Badge variant="outline">{stats?.currentStreak || 0} days</Badge>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="monthly" className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Workouts</span>
                        <Badge variant="outline">{monthlyStats.workoutDays}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Rest Days</span>
                        <Badge variant="outline">{monthlyStats.restDays}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Completion</span>
                        <Badge variant="outline">{monthlyStats.completionRate}%</Badge>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="h-5 w-5 text-yellow-500 mr-2" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                      <Flame className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">First Workout</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Completed your first workout</p>
                    </div>
                  </div>
                  
                  {(stats?.currentStreak || 0) >= 7 && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                        <Calendar className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Week Warrior</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">7 day workout streak</p>
                      </div>
                    </div>
                  )}
                  
                  {(stats?.totalWorkouts || 0) >= 10 && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
                        <Target className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Dedicated</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">10 workouts completed</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
