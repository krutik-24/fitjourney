import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BMICalculator } from '@/components/BMICalculator';
import { WorkoutGenerator } from '@/components/WorkoutGenerator';
import { WorkoutCalendar } from '@/components/WorkoutCalendar';
import { CommunityFeed } from '@/components/CommunityFeed';
import { Leaderboard } from '@/components/Leaderboard';
import { ProgressChart } from '@/components/ProgressChart';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { isUnauthorizedError } from '@/lib/authUtils';
import { 
  Flame, 
  Weight, 
  Dumbbell, 
  Heart, 
  UserPlus, 
  Share2,
  Plus
} from 'lucide-react';

interface UserStats {
  currentStreak: number;
  totalWorkouts: number;
  weightProgress: number;
  bmiStatus: string;
}

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ['/api/user/stats'],
    queryFn: async () => {
      const response = await fetch('/api/user/stats');
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    },
  });

  const shareProgressMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', '/api/posts', {
        content,
        postType: 'streak',
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({
        title: "Progress Shared!",
        description: "Your achievement has been shared with the community.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to share progress. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleShareProgress = () => {
    if (stats) {
      const content = `🔥 ${stats.currentStreak} day workout streak! Feeling stronger every day. #FitnessGoals`;
      shareProgressMutation.mutate(content);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mb-16 md:mb-0">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Welcome Section */}
          <div className="bg-gradient-to-r from-primary to-blue-600 rounded-2xl p-8 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">
                  Welcome back, {user?.firstName || 'Fitness Enthusiast'}!
                </h1>
                <p className="text-blue-100 text-lg">Ready to crush your fitness goals today?</p>
              </div>
              <div className="hidden sm:block">
                <Flame className="h-16 w-16 text-blue-200" />
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Current Streak</p>
                  <p className="text-2xl font-bold text-green-600">
                    {statsLoading ? '...' : stats?.currentStreak || 0}
                  </p>
                </div>
                <Flame className="h-8 w-8 text-green-600" />
              </div>
            </Card>
            
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Weight Progress</p>
                  <p className="text-2xl font-bold text-primary">
                    {statsLoading ? '...' : stats?.weightProgress ? `${stats.weightProgress > 0 ? '+' : ''}${stats.weightProgress.toFixed(1)} kg` : 'N/A'}
                  </p>
                </div>
                <Weight className="h-8 w-8 text-primary" />
              </div>
            </Card>
            
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Workouts</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {statsLoading ? '...' : stats?.totalWorkouts || 0}
                  </p>
                </div>
                <Dumbbell className="h-8 w-8 text-yellow-600" />
              </div>
            </Card>
            
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">BMI Status</p>
                  <p className="text-2xl font-bold text-green-600">
                    {statsLoading ? '...' : stats?.bmiStatus || 'Unknown'}
                  </p>
                </div>
                <Heart className="h-8 w-8 text-green-600" />
              </div>
            </Card>
          </div>

          {/* AI Workout Generation */}
          <WorkoutGenerator />

          {/* Workout Calendar */}
          <WorkoutCalendar />

          {/* Community Feed */}
          <CommunityFeed />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          
          {/* BMI Calculator */}
          <BMICalculator />

          {/* Progress Chart */}
          <ProgressChart />

          {/* Leaderboard */}
          <Leaderboard />

          {/* Quick Actions */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Plus className="h-5 w-5 text-primary mr-2" />
                Quick Actions
              </h3>
              
              <div className="space-y-3">
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    const today = new Date().toISOString().split('T')[0];
                    // This would trigger the workout completion flow
                    toast({
                      title: "Workout Logged",
                      description: "Great job on completing your workout!",
                    });
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Log Workout
                </Button>
                
                <Button 
                  className="w-full"
                  onClick={() => window.location.href = '/community'}
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Find Friends
                </Button>
                
                <Button 
                  className="w-full bg-yellow-600 hover:bg-yellow-700"
                  onClick={handleShareProgress}
                  disabled={shareProgressMutation.isPending}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Share Progress
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
