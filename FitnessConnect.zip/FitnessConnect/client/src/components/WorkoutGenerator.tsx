import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { isUnauthorizedError } from '@/lib/authUtils';
import { Bot, Save, Trash2, RefreshCw, Dumbbell, Home, Users } from 'lucide-react';

interface Exercise {
  name: string;
  sets: number;
  reps: number | string;
  rest: number;
}

interface Workout {
  title: string;
  description: string;
  exercises: Exercise[];
}

export function WorkoutGenerator() {
  const [generatedWorkout, setGeneratedWorkout] = useState<Workout | null>(null);
  const [selectedEquipment, setSelectedEquipment] = useState<string[]>([]);
  const [workoutDuration, setWorkoutDuration] = useState<string>('30');
  const [workoutType, setWorkoutType] = useState<string>('balanced');
  const [showPreferences, setShowPreferences] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const equipment = [
    { id: 'dumbbells', name: 'Dumbbells', icon: Dumbbell },
    { id: 'barbell', name: 'Barbell', icon: Dumbbell },
    { id: 'resistance_bands', name: 'Resistance Bands', icon: Dumbbell },
    { id: 'kettlebell', name: 'Kettlebell', icon: Dumbbell },
    { id: 'pull_up_bar', name: 'Pull-up Bar', icon: Dumbbell },
    { id: 'bodyweight', name: 'Bodyweight Only', icon: Home },
    { id: 'yoga_mat', name: 'Yoga Mat', icon: Home },
    { id: 'gym_access', name: 'Full Gym Access', icon: Users },
  ];

  const generateWorkoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/generate-workout', {
        equipment: selectedEquipment,
        duration: parseInt(workoutDuration),
        workoutType,
      });
      return response.json();
    },
    onSuccess: (workout) => {
      setGeneratedWorkout(workout);
      toast({
        title: "Workout Generated",
        description: "Your AI-powered workout plan is ready!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate workout. Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveWorkoutMutation = useMutation({
    mutationFn: async (workout: Workout) => {
      const response = await apiRequest('POST', '/api/workouts', {
        title: workout.title,
        description: workout.description,
        exercises: workout.exercises,
        shared: false,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workouts'] });
      toast({
        title: "Workout Saved",
        description: "Your workout has been added to your routine!",
      });
      setGeneratedWorkout(null);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save workout. Please try again.",
        variant: "destructive",
      });
    },
  });

  const discardWorkout = () => {
    setGeneratedWorkout(null);
    toast({
      title: "Workout Discarded",
      description: "The generated workout has been discarded.",
    });
  };

  const saveWorkout = () => {
    if (generatedWorkout) {
      saveWorkoutMutation.mutate(generatedWorkout);
    }
  };

  const handleEquipmentChange = (equipmentId: string, checked: boolean) => {
    if (checked) {
      setSelectedEquipment([...selectedEquipment, equipmentId]);
    } else {
      setSelectedEquipment(selectedEquipment.filter(id => id !== equipmentId));
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bot className="h-5 w-5 text-primary mr-2" />
          AI Workout Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {!generatedWorkout ? (
          <div className="space-y-6">
            <div className="text-center py-4">
              <Bot className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Ready to generate your AI workout?</h3>
              <p className="text-muted-foreground mb-6">
                Get a personalized workout plan based on your fitness goals and preferences.
              </p>
            </div>

            {/* Workout Preferences */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-md font-medium">Workout Preferences</h4>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPreferences(!showPreferences)}
                >
                  {showPreferences ? 'Hide' : 'Show'} Options
                </Button>
              </div>

              {showPreferences && (
                <div className="space-y-6 p-4 bg-muted/20 rounded-lg">
                  {/* Workout Type */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Workout Type</Label>
                    <Select value={workoutType} onValueChange={setWorkoutType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="strength">Strength Training</SelectItem>
                        <SelectItem value="cardio">Cardio Focus</SelectItem>
                        <SelectItem value="balanced">Balanced (Strength + Cardio)</SelectItem>
                        <SelectItem value="flexibility">Flexibility & Mobility</SelectItem>
                        <SelectItem value="hiit">High-Intensity Interval Training</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Duration */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Duration (minutes)</Label>
                    <Select value={workoutDuration} onValueChange={setWorkoutDuration}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="45">45 minutes</SelectItem>
                        <SelectItem value="60">60 minutes</SelectItem>
                        <SelectItem value="90">90 minutes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Equipment Selection */}
                  <div className="space-y-3">
                    <Label className="text-sm font-medium">Available Equipment</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {equipment.map((item) => {
                        const Icon = item.icon;
                        return (
                          <div key={item.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={item.id}
                              checked={selectedEquipment.includes(item.id)}
                              onCheckedChange={(checked) => handleEquipmentChange(item.id, checked as boolean)}
                            />
                            <Label
                              htmlFor={item.id}
                              className="flex items-center space-x-2 text-sm cursor-pointer"
                            >
                              <Icon className="h-4 w-4" />
                              <span>{item.name}</span>
                            </Label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="text-center">
              <Button
                onClick={() => generateWorkoutMutation.mutate()}
                disabled={generateWorkoutMutation.isPending}
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
              >
                {generateWorkoutMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Bot className="h-4 w-4 mr-2" />
                    Generate Workout
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
              <h3 className="font-semibold mb-2">{generatedWorkout.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                {generatedWorkout.description}
              </p>
              <div className="space-y-2">
                {generatedWorkout.exercises.map((exercise, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-sm font-medium">{exercise.name}</span>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        {exercise.sets} sets × {exercise.reps} reps
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {exercise.rest}s rest
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                onClick={saveWorkout}
                disabled={saveWorkoutMutation.isPending}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Workout
              </Button>
              <Button
                onClick={discardWorkout}
                variant="outline"
                className="flex-1"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Discard
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
