import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { isUnauthorizedError } from '@/lib/authUtils';
import { PostWithUser } from '@shared/schema';
import { Users, Heart, MessageCircle, Share2, TrendingUp } from 'lucide-react';

export function CommunityFeed() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['/api/posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts?limit=10');
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest('POST', `/api/posts/${postId}/like`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to like post.",
        variant: "destructive",
      });
    },
  });

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const postDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - postDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  const getPostIcon = (postType: string) => {
    switch (postType) {
      case 'streak':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'workout':
        return <Heart className="h-4 w-4 text-red-500" />;
      default:
        return <MessageCircle className="h-4 w-4 text-blue-500" />;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 text-primary mr-2" />
            Community Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Users className="h-5 w-5 text-primary mr-2" />
          Community Feed
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {posts.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">
                No posts yet. Be the first to share your progress!
              </p>
            </div>
          ) : (
            posts.map((post: PostWithUser) => (
              <div key={post.id} className="border-b border-gray-200 dark:border-gray-700 pb-4 last:border-b-0">
                <div className="flex items-start space-x-3">
                  <Avatar>
                    <AvatarImage 
                      src={post.user.profileImageUrl || `https://ui-avatars.com/api/?name=${post.user.firstName}+${post.user.lastName}&background=2563eb&color=fff`}
                      alt={`${post.user.firstName} ${post.user.lastName}`}
                    />
                    <AvatarFallback>
                      {post.user.firstName?.[0]}{post.user.lastName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-semibold text-sm">
                        {post.user.firstName} {post.user.lastName}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatTimeAgo(post.createdAt!)}
                      </span>
                      {post.postType && (
                        <Badge variant="outline" className="text-xs">
                          {getPostIcon(post.postType)}
                          <span className="ml-1">{post.postType}</span>
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                      {post.content}
                    </p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-0 h-auto text-xs"
                        onClick={() => likeMutation.mutate(post.id)}
                      >
                        <Heart className="h-3 w-3 mr-1" />
                        {post.likesCount || 0}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-0 h-auto text-xs"
                      >
                        <MessageCircle className="h-3 w-3 mr-1" />
                        Comment
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-0 h-auto text-xs"
                      >
                        <Share2 className="h-3 w-3 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
