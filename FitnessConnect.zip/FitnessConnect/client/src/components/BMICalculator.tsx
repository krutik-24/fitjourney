import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Calculator } from 'lucide-react';

export function BMICalculator() {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState<string>('');

  const calculateBMI = () => {
    if (!height || !weight) return;

    const heightInM = parseFloat(height) / 100;
    const weightInKg = parseFloat(weight);
    const bmiValue = weightInKg / (heightInM * heightInM);
    
    setBmi(bmiValue);
    
    if (bmiValue < 18.5) {
      setCategory('Underweight');
    } else if (bmiValue < 25) {
      setCategory('Normal Weight');
    } else if (bmiValue < 30) {
      setCategory('Overweight');
    } else {
      setCategory('Obese');
    }
  };

  const getBMIProgress = () => {
    if (!bmi) return 0;
    // Map BMI to progress bar (0-100)
    if (bmi < 18.5) return (bmi / 18.5) * 25;
    if (bmi < 25) return 25 + ((bmi - 18.5) / 6.5) * 50;
    if (bmi < 30) return 75 + ((bmi - 25) / 5) * 20;
    return 95;
  };

  const getBMIColor = () => {
    if (!bmi) return 'bg-gray-200';
    if (bmi < 18.5) return 'bg-blue-500';
    if (bmi < 25) return 'bg-green-500';
    if (bmi < 30) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center text-lg">
          <Calculator className="h-5 w-5 text-primary mr-2" />
          BMI Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="height">Height (cm)</Label>
            <Input
              id="height"
              type="number"
              placeholder="175"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input
              id="weight"
              type="number"
              placeholder="70"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
            />
          </div>
        </div>
        
        {bmi && (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Current BMI</span>
              <span className="text-xl font-bold text-primary">{bmi.toFixed(1)}</span>
            </div>
            <Progress value={getBMIProgress()} className="h-2 mb-2" />
            <p className="text-xs text-center font-medium text-green-600 dark:text-green-400">
              {category}
            </p>
          </div>
        )}
        
        <Button 
          onClick={calculateBMI} 
          className="w-full"
          disabled={!height || !weight}
        >
          Calculate BMI
        </Button>
      </CardContent>
    </Card>
  );
}
