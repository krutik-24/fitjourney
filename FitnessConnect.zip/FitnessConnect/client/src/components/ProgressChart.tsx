import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Target, Weight, Activity } from 'lucide-react';

interface UserStats {
  currentStreak: number;
  totalWorkouts: number;
  weightProgress: number;
  bmiStatus: string;
}

export function ProgressChart() {
  const { data: stats, isLoading } = useQuery<UserStats>({
    queryKey: ['/api/user/stats'],
    queryFn: async () => {
      const response = await fetch('/api/user/stats');
      if (!response.ok) throw new Error('Failed to fetch stats');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 text-primary mr-2" />
            Progress Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-2 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 text-primary mr-2" />
            Progress Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">
              No progress data yet. Start your fitness journey!
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStreakProgress = () => {
    // Convert streak to progress percentage (max 30 days = 100%)
    return Math.min((stats.currentStreak / 30) * 100, 100);
  };

  const getWorkoutProgress = () => {
    // Convert workouts to progress percentage (max 50 workouts = 100%)
    return Math.min((stats.totalWorkouts / 50) * 100, 100);
  };

  const getWeightProgress = () => {
    // Simplified weight progress (assuming 10kg target = 100%)
    return Math.min((Math.abs(stats.weightProgress) / 10) * 100, 100);
  };

  const getBMIStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'normal':
        return 'text-green-600 dark:text-green-400';
      case 'underweight':
        return 'text-blue-600 dark:text-blue-400';
      case 'overweight':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'obese':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="h-5 w-5 text-primary mr-2" />
          Progress Overview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Streak */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium">Current Streak</span>
            </div>
            <span className="text-sm font-bold text-green-600">
              {stats.currentStreak} days
            </span>
          </div>
          <Progress value={getStreakProgress()} className="h-2" />
          <p className="text-xs text-gray-600 dark:text-gray-400">
            Keep going! Target: 30 days
          </p>
        </div>

        {/* Total Workouts */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Target className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium">Total Workouts</span>
            </div>
            <span className="text-sm font-bold text-blue-600">
              {stats.totalWorkouts}
            </span>
          </div>
          <Progress value={getWorkoutProgress()} className="h-2" />
          <p className="text-xs text-gray-600 dark:text-gray-400">
            Target: 50 workouts
          </p>
        </div>

        {/* Weight Progress */}
        {stats.weightProgress !== 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Weight className="h-4 w-4 text-purple-500" />
                <span className="text-sm font-medium">Weight Progress</span>
              </div>
              <span className="text-sm font-bold text-purple-600">
                {stats.weightProgress > 0 ? '+' : ''}{stats.weightProgress.toFixed(1)} kg
              </span>
            </div>
            <Progress value={getWeightProgress()} className="h-2" />
            <p className="text-xs text-gray-600 dark:text-gray-400">
              {stats.weightProgress > 0 ? 'Gained' : 'Lost'} from target
            </p>
          </div>
        )}

        {/* BMI Status */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">BMI Status</span>
            <span className={`text-sm font-bold ${getBMIStatusColor(stats.bmiStatus)}`}>
              {stats.bmiStatus}
            </span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            Based on your current height and weight
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
