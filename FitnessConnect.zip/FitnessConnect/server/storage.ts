import {
  users,
  workouts,
  posts,
  streaks,
  workoutCompletions,
  type User,
  type UpsertUser,
  type InsertWorkout,
  type Workout,
  type InsertPost,
  type Post,
  type PostWithUser,
  type Streak,
  type WorkoutCompletion,
  type InsertWorkoutCompletion,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Workout operations
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  getUserWorkouts(userId: string): Promise<Workout[]>;
  updateWorkout(id: number, updates: Partial<Workout>): Promise<Workout>;
  deleteWorkout(id: number): Promise<void>;
  
  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPostsWithUsers(limit?: number): Promise<PostWithUser[]>;
  getUserPosts(userId: string): Promise<PostWithUser[]>;
  likePost(postId: number): Promise<void>;
  
  // Streak operations
  getUserStreak(userId: string): Promise<Streak | undefined>;
  updateStreak(userId: string, currentStreak: number, longestStreak: number): Promise<Streak>;
  getLeaderboard(limit?: number): Promise<(Streak & { user: User })[]>;
  
  // Workout completion operations
  markWorkoutComplete(completion: InsertWorkoutCompletion): Promise<WorkoutCompletion>;
  getUserCompletions(userId: string, month?: number, year?: number): Promise<WorkoutCompletion[]>;
  
  // User stats
  getUserStats(userId: string): Promise<{
    currentStreak: number;
    totalWorkouts: number;
    weightProgress: number;
    bmiStatus: string;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async createWorkout(workout: InsertWorkout): Promise<Workout> {
    const [newWorkout] = await db
      .insert(workouts)
      .values(workout)
      .returning();
    return newWorkout;
  }

  async getUserWorkouts(userId: string): Promise<Workout[]> {
    return await db
      .select()
      .from(workouts)
      .where(eq(workouts.userId, userId))
      .orderBy(desc(workouts.createdAt));
  }

  async updateWorkout(id: number, updates: Partial<Workout>): Promise<Workout> {
    const [updatedWorkout] = await db
      .update(workouts)
      .set(updates)
      .where(eq(workouts.id, id))
      .returning();
    return updatedWorkout;
  }

  async deleteWorkout(id: number): Promise<void> {
    await db.delete(workouts).where(eq(workouts.id, id));
  }

  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db
      .insert(posts)
      .values(post)
      .returning();
    return newPost;
  }

  async getPostsWithUsers(limit: number = 10): Promise<PostWithUser[]> {
    const result = await db
      .select()
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .orderBy(desc(posts.createdAt))
      .limit(limit);
    
    return result.map(row => ({
      ...row.posts,
      user: row.users!,
    }));
  }

  async getUserPosts(userId: string): Promise<PostWithUser[]> {
    const result = await db
      .select()
      .from(posts)
      .leftJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
    
    return result.map(row => ({
      ...row.posts,
      user: row.users!,
    }));
  }

  async likePost(postId: number): Promise<void> {
    await db
      .update(posts)
      .set({
        likesCount: sql`${posts.likesCount} + 1`,
      })
      .where(eq(posts.id, postId));
  }

  async getUserStreak(userId: string): Promise<Streak | undefined> {
    const [streak] = await db
      .select()
      .from(streaks)
      .where(eq(streaks.userId, userId));
    return streak;
  }

  async updateStreak(userId: string, currentStreak: number, longestStreak: number): Promise<Streak> {
    const [updatedStreak] = await db
      .insert(streaks)
      .values({
        userId,
        currentStreak,
        longestStreak,
        lastWorkoutDate: new Date().toISOString().split('T')[0],
      })
      .onConflictDoUpdate({
        target: streaks.userId,
        set: {
          currentStreak,
          longestStreak,
          lastWorkoutDate: new Date().toISOString().split('T')[0],
        },
      })
      .returning();
    return updatedStreak;
  }

  async getLeaderboard(limit: number = 10): Promise<(Streak & { user: User })[]> {
    const result = await db
      .select()
      .from(streaks)
      .leftJoin(users, eq(streaks.userId, users.id))
      .orderBy(desc(streaks.currentStreak))
      .limit(limit);
    
    return result.map(row => ({
      ...row.streaks,
      user: row.users!,
    }));
  }

  async markWorkoutComplete(completion: InsertWorkoutCompletion): Promise<WorkoutCompletion> {
    const [newCompletion] = await db
      .insert(workoutCompletions)
      .values(completion)
      .returning();
    return newCompletion;
  }

  async getUserCompletions(userId: string, month?: number, year?: number): Promise<WorkoutCompletion[]> {
    let whereConditions = [eq(workoutCompletions.userId, userId)];
    
    if (month !== undefined && year !== undefined) {
      whereConditions.push(
        sql`EXTRACT(MONTH FROM ${workoutCompletions.completedDate}) = ${month}`,
        sql`EXTRACT(YEAR FROM ${workoutCompletions.completedDate}) = ${year}`
      );
    }
    
    return await db
      .select()
      .from(workoutCompletions)
      .where(and(...whereConditions))
      .orderBy(desc(workoutCompletions.completedDate));
  }

  async getUserStats(userId: string): Promise<{
    currentStreak: number;
    totalWorkouts: number;
    weightProgress: number;
    bmiStatus: string;
  }> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const [streak] = await db.select().from(streaks).where(eq(streaks.userId, userId));
    const [workoutCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(workouts)
      .where(eq(workouts.userId, userId));
    
    const currentStreak = streak?.currentStreak || 0;
    const totalWorkouts = workoutCount?.count || 0;
    
    // Calculate weight progress (simplified)
    const weightProgress = user?.targetWeight && user?.weight 
      ? parseFloat(user.weight) - parseFloat(user.targetWeight)
      : 0;
    
    // Calculate BMI status
    let bmiStatus = "Unknown";
    if (user?.height && user?.weight) {
      const heightInM = parseFloat(user.height) / 100;
      const bmi = parseFloat(user.weight) / (heightInM * heightInM);
      if (bmi < 18.5) bmiStatus = "Underweight";
      else if (bmi < 25) bmiStatus = "Normal";
      else if (bmi < 30) bmiStatus = "Overweight";
      else bmiStatus = "Obese";
    }
    
    return {
      currentStreak,
      totalWorkouts,
      weightProgress,
      bmiStatus,
    };
  }
}

export const storage = new DatabaseStorage();
