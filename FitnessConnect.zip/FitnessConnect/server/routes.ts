import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertWorkoutSchema, insertPostSchema, insertWorkoutCompletionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User profile routes
  app.patch('/api/user/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = req.body;
      const user = await storage.upsertUser({ id: userId, ...updates });
      res.json(user);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // User stats route
  app.get('/api/user/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Workout routes
  app.post('/api/workouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workoutData = insertWorkoutSchema.parse({ ...req.body, userId });
      const workout = await storage.createWorkout(workoutData);
      res.json(workout);
    } catch (error) {
      console.error("Error creating workout:", error);
      res.status(500).json({ message: "Failed to create workout" });
    }
  });

  app.get('/api/workouts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workouts = await storage.getUserWorkouts(userId);
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching workouts:", error);
      res.status(500).json({ message: "Failed to fetch workouts" });
    }
  });

  app.patch('/api/workouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const workoutId = parseInt(req.params.id);
      const updates = req.body;
      const workout = await storage.updateWorkout(workoutId, updates);
      res.json(workout);
    } catch (error) {
      console.error("Error updating workout:", error);
      res.status(500).json({ message: "Failed to update workout" });
    }
  });

  app.delete('/api/workouts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const workoutId = parseInt(req.params.id);
      await storage.deleteWorkout(workoutId);
      res.json({ message: "Workout deleted successfully" });
    } catch (error) {
      console.error("Error deleting workout:", error);
      res.status(500).json({ message: "Failed to delete workout" });
    }
  });

  // AI workout generation
  app.post('/api/generate-workout', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { equipment = [], duration = 30, workoutType = 'balanced' } = req.body;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Use DeepSeek API or provide a structured workout plan
      const apiKey = process.env.DEEPSEEK_API_KEY;
      if (!apiKey) {
        // Fallback structured workout with equipment and preferences
        const workout = generateStructuredWorkout(user, equipment, duration, workoutType);
        return res.json(workout);
      }

      // Prepare equipment string for API
      const equipmentList = equipment.length > 0 ? equipment.join(', ') : 'bodyweight only';
      
      // Call DeepSeek API
      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: 'You are a fitness expert. Generate a detailed workout plan based on user information and equipment available. Return only valid JSON.'
            },
            {
              role: 'user',
              content: `Create a personalized ${workoutType} workout plan for ${duration} minutes with the following specifications:
              
              User Profile:
              - Goal: ${user.fitnessGoal || 'general fitness'}
              - Weight: ${user.weight || 'unknown'}
              - Height: ${user.height || 'unknown'}
              - Activity Level: ${user.activityLevel || 'moderate'}
              
              Available Equipment: ${equipmentList}
              Duration: ${duration} minutes
              Workout Type: ${workoutType}
              
              Return as JSON with:
              {
                "title": "Workout name",
                "description": "Brief description",
                "exercises": [
                  {
                    "name": "Exercise name",
                    "sets": number,
                    "reps": "number or time-based",
                    "rest": number_in_seconds
                  }
                ]
              }`
            }
          ],
          max_tokens: 1000,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error('DeepSeek API request failed');
      }

      const data = await response.json();
      const workoutContent = data.choices[0].message.content;
      
      try {
        const workout = JSON.parse(workoutContent);
        res.json(workout);
      } catch {
        // If JSON parsing fails, return structured format
        const workout = generateStructuredWorkout(user, equipment, duration, workoutType);
        res.json(workout);
      }
    } catch (error) {
      console.error("Error generating workout:", error);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const workout = generateStructuredWorkout(user);
      res.json(workout);
    }
  });

  // Meal plan generation
  app.post('/api/generate-meal-plan', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { dietaryRestrictions } = req.body;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const apiKey = process.env.DEEPSEEK_API_KEY;
      if (!apiKey) {
        const mealPlan = generateStructuredMealPlan(user, dietaryRestrictions);
        return res.json(mealPlan);
      }

      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: 'You are a nutrition expert. Generate a detailed meal plan based on user information.'
            },
            {
              role: 'user',
              content: `Create a daily meal plan for: Goal: ${user.fitnessGoal || 'general fitness'}, Weight: ${user.weight || 'unknown'}, Dietary restrictions: ${dietaryRestrictions || 'none'}. Return as JSON with breakfast, lunch, dinner, and snacks, each with name, calories, protein, carbs, fats.`
            }
          ],
          max_tokens: 1500,
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error('DeepSeek API request failed');
      }

      const data = await response.json();
      const mealContent = data.choices[0].message.content;
      
      try {
        const mealPlan = JSON.parse(mealContent);
        res.json(mealPlan);
      } catch {
        const mealPlan = generateStructuredMealPlan(user, dietaryRestrictions);
        res.json(mealPlan);
      }
    } catch (error) {
      console.error("Error generating meal plan:", error);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const mealPlan = generateStructuredMealPlan(user, req.body.dietaryRestrictions);
      res.json(mealPlan);
    }
  });

  // Workout completion routes
  app.post('/api/workout-completions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const completionData = insertWorkoutCompletionSchema.parse({ ...req.body, userId });
      const completion = await storage.markWorkoutComplete(completionData);
      
      // Update streak
      const today = new Date().toISOString().split('T')[0];
      const streak = await storage.getUserStreak(userId);
      const newStreak = streak ? (streak.currentStreak || 0) + 1 : 1;
      const longestStreak = streak ? Math.max(streak.longestStreak || 0, newStreak) : newStreak;
      
      await storage.updateStreak(userId, newStreak, longestStreak);
      
      res.json(completion);
    } catch (error) {
      console.error("Error marking workout complete:", error);
      res.status(500).json({ message: "Failed to mark workout complete" });
    }
  });

  app.get('/api/workout-completions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { month, year } = req.query;
      const completions = await storage.getUserCompletions(
        userId,
        month ? parseInt(month as string) : undefined,
        year ? parseInt(year as string) : undefined
      );
      res.json(completions);
    } catch (error) {
      console.error("Error fetching workout completions:", error);
      res.status(500).json({ message: "Failed to fetch completions" });
    }
  });

  // Post routes
  app.post('/api/posts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postData = insertPostSchema.parse({ ...req.body, userId });
      const post = await storage.createPost(postData);
      res.json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.get('/api/posts', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const posts = await storage.getPostsWithUsers(limit);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.post('/api/posts/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const postId = parseInt(req.params.id);
      await storage.likePost(postId);
      res.json({ message: "Post liked successfully" });
    } catch (error) {
      console.error("Error liking post:", error);
      res.status(500).json({ message: "Failed to like post" });
    }
  });

  // Leaderboard route
  app.get('/api/leaderboard', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const leaderboard = await storage.getLeaderboard(limit);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time features
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Broadcast to all connected clients
        wss.clients.forEach((client) => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(data));
          }
        });
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  return httpServer;
}

function generateStructuredWorkout(user: any, equipment: string[] = [], duration: number = 30, workoutType: string = 'balanced') {
  const hasGymAccess = equipment.includes('gym_access');
  const hasDumbbells = equipment.includes('dumbbells');
  const hasBarbell = equipment.includes('barbell');
  const hasResistanceBands = equipment.includes('resistance_bands');
  const hasKettlebell = equipment.includes('kettlebell');
  const bodyweightOnly = equipment.includes('bodyweight') || equipment.length === 0;
  
  // Generate exercises based on equipment and workout type
  let exercises = [];
  
  if (workoutType === 'strength' && hasGymAccess) {
    exercises = [
      { name: 'Barbell Squats', sets: 4, reps: 8, rest: 90 },
      { name: 'Bench Press', sets: 4, reps: 8, rest: 90 },
      { name: 'Deadlifts', sets: 3, reps: 6, rest: 120 },
      { name: 'Overhead Press', sets: 3, reps: 8, rest: 90 },
      { name: 'Pull-ups', sets: 3, reps: 10, rest: 90 },
    ];
  } else if (workoutType === 'strength' && hasDumbbells) {
    exercises = [
      { name: 'Dumbbell Squats', sets: 4, reps: 10, rest: 60 },
      { name: 'Dumbbell Bench Press', sets: 4, reps: 10, rest: 60 },
      { name: 'Dumbbell Rows', sets: 3, reps: 12, rest: 60 },
      { name: 'Dumbbell Shoulder Press', sets: 3, reps: 10, rest: 60 },
      { name: 'Dumbbell Deadlifts', sets: 3, reps: 10, rest: 60 },
    ];
  } else if (workoutType === 'cardio') {
    exercises = [
      { name: 'Jumping Jacks', sets: 4, reps: 30, rest: 30 },
      { name: 'High Knees', sets: 4, reps: 20, rest: 30 },
      { name: 'Burpees', sets: 3, reps: 10, rest: 60 },
      { name: 'Mountain Climbers', sets: 4, reps: 30, rest: 30 },
      { name: 'Jump Squats', sets: 3, reps: 15, rest: 45 },
    ];
  } else if (workoutType === 'hiit') {
    exercises = [
      { name: 'Burpees', sets: 4, reps: 15, rest: 60 },
      { name: 'Mountain Climbers', sets: 4, reps: 30, rest: 45 },
      { name: 'Jump Squats', sets: 4, reps: 20, rest: 60 },
      { name: 'Push-ups', sets: 3, reps: 15, rest: 45 },
      { name: 'Plank', sets: 3, reps: '60 seconds', rest: 90 },
    ];
  } else if (workoutType === 'flexibility') {
    exercises = [
      { name: 'Cat-Cow Stretch', sets: 2, reps: 10, rest: 30 },
      { name: 'Downward Dog', sets: 3, reps: '30 seconds', rest: 30 },
      { name: 'Pigeon Pose', sets: 2, reps: '45 seconds each side', rest: 30 },
      { name: 'Seated Forward Fold', sets: 3, reps: '30 seconds', rest: 30 },
      { name: 'Child\'s Pose', sets: 1, reps: '60 seconds', rest: 0 },
    ];
  } else { // balanced
    if (hasGymAccess) {
      exercises = [
        { name: 'Goblet Squats', sets: 3, reps: 12, rest: 60 },
        { name: 'Push-ups', sets: 3, reps: 10, rest: 60 },
        { name: 'Bent-over Rows', sets: 3, reps: 12, rest: 60 },
        { name: 'Plank', sets: 3, reps: '45 seconds', rest: 60 },
        { name: 'Jumping Jacks', sets: 2, reps: 30, rest: 30 },
      ];
    } else {
      exercises = [
        { name: 'Bodyweight Squats', sets: 3, reps: 15, rest: 60 },
        { name: 'Push-ups', sets: 3, reps: 10, rest: 60 },
        { name: 'Lunges', sets: 3, reps: 12, rest: 60 },
        { name: 'Plank', sets: 3, reps: '45 seconds', rest: 60 },
        { name: 'Jumping Jacks', sets: 2, reps: 30, rest: 30 },
      ];
    }
  }
  
  // Adjust for duration
  if (duration < 30) {
    exercises = exercises.slice(0, 3); // Shorter workout
  } else if (duration > 60) {
    exercises.push({ name: 'Cool-down Stretches', sets: 1, reps: '5 minutes', rest: 0 });
  }
  
  const goalType = user?.fitnessGoal || 'general fitness';
  const equipmentText = equipment.length > 0 ? equipment.join(', ') : 'bodyweight';
  
  return {
    title: `${workoutType.charAt(0).toUpperCase() + workoutType.slice(1)} Workout (${duration} min)`,
    description: `A personalized ${workoutType} workout for ${goalType} using ${equipmentText}`,
    exercises
  };
}

function generateStructuredMealPlan(user: any, dietaryRestrictions: string[] = []) {
  const isVegetarian = dietaryRestrictions.includes('vegetarian');
  const isVegan = dietaryRestrictions.includes('vegan');
  
  const mealPlan = {
    breakfast: {
      name: isVegan ? 'Oatmeal with Berries and Nuts' : 'Greek Yogurt with Berries',
      calories: 300,
      protein: isVegan ? 8 : 15,
      carbs: 45,
      fats: 10
    },
    lunch: {
      name: isVegan ? 'Quinoa Buddha Bowl' : (isVegetarian ? 'Vegetarian Wrap' : 'Grilled Chicken Salad'),
      calories: 450,
      protein: isVegan ? 12 : (isVegetarian ? 15 : 25),
      carbs: 35,
      fats: 18
    },
    dinner: {
      name: isVegan ? 'Lentil Curry with Rice' : (isVegetarian ? 'Vegetable Pasta' : 'Salmon with Vegetables'),
      calories: 500,
      protein: isVegan ? 18 : (isVegetarian ? 20 : 30),
      carbs: 60,
      fats: 15
    },
    snacks: {
      name: isVegan ? 'Mixed Nuts and Fruit' : 'Protein Smoothie',
      calories: 200,
      protein: isVegan ? 6 : 15,
      carbs: 25,
      fats: 12
    }
  };

  return mealPlan;
}
